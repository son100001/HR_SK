Imports VBReport
Imports System.Text.RegularExpressions
Imports System.Windows.Forms
Imports System.IO
Imports Janus.Windows.GridEX

Public Class frmPara
    Inherits System.Windows.Forms.Form
    Dim tvcn As New ThuVienChucNang
    Private obj As New DbSetting
    Dim kn As New Entity.connect(DbSetting.dataPath)
    Public ParameterReturn As String
    Public ReportInformation As DataRow
    Public bThucHienLenh As Boolean
    Public bViewOnGrid, bPrintView, bPrintViewDocument As Boolean
    Public KeyOfForm1 As String
    Public Quyen As String
    Dim tabQuyenTX As DataTable
    Friend WithEvents para_Year As Year
    Friend WithEvents lblChucDanh As Label
    Friend WithEvents para_ChucDanh As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents UltraTabPageControl10 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents para_year_ As Year
    Friend WithEvents lblYear_ As Label
    Friend WithEvents ExportDocumentFile As RadioButton
    Friend WithEvents lblFactory_ID As Label
    Friend WithEvents para_Factory_ID As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents para_Position As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents lblChooseAll As Label
    Friend WithEvents btnXoa As Janus.Windows.EditControls.UIButton
    Friend WithEvents UltraTabPageControl11 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents para_LeaveType As Janus.Windows.GridEX.GridEX
    Friend WithEvents para_Month As Month


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents UltraTabPageControl1 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabSharedControlsPage1 As Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage
    Friend WithEvents UltraTabPageControl2 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabControl1 As Infragistics.Win.UltraWinTabControl.UltraTabControl
    Friend WithEvents lblsectioncode As System.Windows.Forms.Label
    Friend WithEvents lblPositionCategory_ID As System.Windows.Forms.Label
    Friend WithEvents UltraTabPageControl3 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents UltraTabPageControl4 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents lbltodate As System.Windows.Forms.Label
    Friend WithEvents lblfromdate As System.Windows.Forms.Label
    Friend WithEvents lblNgay As System.Windows.Forms.Label
    Friend WithEvents lblMonth_ As System.Windows.Forms.Label
    Friend WithEvents btnOk As Janus.Windows.EditControls.UIButton
    Friend WithEvents para_teamcode As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents para_sectioncode As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents para_departmentcode As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents para_Position_ID As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents para_PositionCategory_ID As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents para_fromdate As Janus.Windows.CalendarCombo.CalendarCombo
    Friend WithEvents para_todate As Janus.Windows.CalendarCombo.CalendarCombo
    Friend WithEvents para_Ngay As Janus.Windows.CalendarCombo.CalendarCombo
    Friend WithEvents gbLuaChonHienThi As System.Windows.Forms.GroupBox
    Friend WithEvents PrintView As System.Windows.Forms.RadioButton
    Friend WithEvents ExportExcel As System.Windows.Forms.RadioButton
    Friend WithEvents ViewOnGrid As System.Windows.Forms.RadioButton
    Friend WithEvents btnCancel As Janus.Windows.EditControls.UIButton
    Friend WithEvents GetTemplateFile As System.Windows.Forms.RadioButton
    Friend WithEvents ExecStore As System.Windows.Forms.RadioButton
    Friend WithEvents InputTemplateFile As System.Windows.Forms.RadioButton
    Friend WithEvents UltraTabPageControl5 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents lblteamcode As System.Windows.Forms.Label
    Friend WithEvents lbldepartmentcode As System.Windows.Forms.Label
    Friend WithEvents lblPosition_ID As System.Windows.Forms.Label
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents para_TypeOfContract As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents PrinViewDocument As System.Windows.Forms.RadioButton
    Friend WithEvents UltraTabPageControl6 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents para_DanhSachKey As System.Windows.Forms.RichTextBox
    Friend WithEvents UltraTabPageControl7 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents gridDanhSachNhanVien As Janus.Windows.GridEX.GridEX
    Friend WithEvents UltraTabPageControl8 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents para_nationality As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Friend WithEvents lblnationality As System.Windows.Forms.Label
    Friend WithEvents UltraTabPageControl9 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents para_SalaryTable As Janus.Windows.GridEX.EditControls.MultiColumnCombo
    Friend WithEvents lblSalaryTable As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim GridEXLayout1 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPara))
        Dim GridEXLayout2 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout3 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout4 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout5 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout6 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout7 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout8 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout9 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout10 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim ValueListItem1 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim ValueListItem2 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem()
        Dim GridEXLayout11 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim GridEXLayout12 As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim UltraTab1 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab2 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab3 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab4 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab5 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab6 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab7 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab8 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab9 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab10 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab11 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Me.UltraTabPageControl1 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.btnXoa = New Janus.Windows.EditControls.UIButton()
        Me.lblChooseAll = New System.Windows.Forms.Label()
        Me.para_Position = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lblFactory_ID = New System.Windows.Forms.Label()
        Me.para_Factory_ID = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lblChucDanh = New System.Windows.Forms.Label()
        Me.para_ChucDanh = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lblsectioncode = New System.Windows.Forms.Label()
        Me.para_teamcode = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lblteamcode = New System.Windows.Forms.Label()
        Me.para_sectioncode = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lbldepartmentcode = New System.Windows.Forms.Label()
        Me.para_departmentcode = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lblPosition_ID = New System.Windows.Forms.Label()
        Me.para_Position_ID = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lblPositionCategory_ID = New System.Windows.Forms.Label()
        Me.para_PositionCategory_ID = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.UltraTabPageControl2 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.para_fromdate = New Janus.Windows.CalendarCombo.CalendarCombo()
        Me.para_todate = New Janus.Windows.CalendarCombo.CalendarCombo()
        Me.lbltodate = New System.Windows.Forms.Label()
        Me.lblfromdate = New System.Windows.Forms.Label()
        Me.UltraTabPageControl3 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.para_Ngay = New Janus.Windows.CalendarCombo.CalendarCombo()
        Me.lblNgay = New System.Windows.Forms.Label()
        Me.UltraTabPageControl4 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.para_Year = New WindowsControlLibrary.Year()
        Me.para_Month = New WindowsControlLibrary.Month()
        Me.lblMonth_ = New System.Windows.Forms.Label()
        Me.UltraTabPageControl5 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.lblType = New System.Windows.Forms.Label()
        Me.para_TypeOfContract = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.UltraTabPageControl6 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.para_DanhSachKey = New System.Windows.Forms.RichTextBox()
        Me.UltraTabPageControl7 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.gridDanhSachNhanVien = New Janus.Windows.GridEX.GridEX()
        Me.UltraTabPageControl8 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.lblnationality = New System.Windows.Forms.Label()
        Me.para_nationality = New Infragistics.Win.UltraWinEditors.UltraComboEditor()
        Me.UltraTabPageControl9 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.para_SalaryTable = New Janus.Windows.GridEX.EditControls.MultiColumnCombo()
        Me.lblSalaryTable = New System.Windows.Forms.Label()
        Me.UltraTabPageControl10 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.para_year_ = New WindowsControlLibrary.Year()
        Me.lblYear_ = New System.Windows.Forms.Label()
        Me.UltraTabPageControl11 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.para_LeaveType = New Janus.Windows.GridEX.GridEX()
        Me.UltraTabSharedControlsPage1 = New Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage()
        Me.UltraTabControl1 = New Infragistics.Win.UltraWinTabControl.UltraTabControl()
        Me.btnOk = New Janus.Windows.EditControls.UIButton()
        Me.gbLuaChonHienThi = New System.Windows.Forms.GroupBox()
        Me.ExportDocumentFile = New System.Windows.Forms.RadioButton()
        Me.PrinViewDocument = New System.Windows.Forms.RadioButton()
        Me.ExecStore = New System.Windows.Forms.RadioButton()
        Me.InputTemplateFile = New System.Windows.Forms.RadioButton()
        Me.GetTemplateFile = New System.Windows.Forms.RadioButton()
        Me.PrintView = New System.Windows.Forms.RadioButton()
        Me.ExportExcel = New System.Windows.Forms.RadioButton()
        Me.ViewOnGrid = New System.Windows.Forms.RadioButton()
        Me.btnCancel = New Janus.Windows.EditControls.UIButton()
        Me.UltraTabPageControl1.SuspendLayout()
        Me.UltraTabPageControl2.SuspendLayout()
        Me.UltraTabPageControl3.SuspendLayout()
        Me.UltraTabPageControl4.SuspendLayout()
        Me.UltraTabPageControl5.SuspendLayout()
        Me.UltraTabPageControl6.SuspendLayout()
        Me.UltraTabPageControl7.SuspendLayout()
        CType(Me.gridDanhSachNhanVien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl8.SuspendLayout()
        CType(Me.para_nationality, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabPageControl9.SuspendLayout()
        Me.UltraTabPageControl10.SuspendLayout()
        Me.UltraTabPageControl11.SuspendLayout()
        CType(Me.para_LeaveType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UltraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabControl1.SuspendLayout()
        Me.gbLuaChonHienThi.SuspendLayout()
        Me.SuspendLayout()
        '
        'UltraTabPageControl1
        '
        Me.UltraTabPageControl1.Controls.Add(Me.btnXoa)
        Me.UltraTabPageControl1.Controls.Add(Me.lblChooseAll)
        Me.UltraTabPageControl1.Controls.Add(Me.para_Position)
        Me.UltraTabPageControl1.Controls.Add(Me.lblFactory_ID)
        Me.UltraTabPageControl1.Controls.Add(Me.para_Factory_ID)
        Me.UltraTabPageControl1.Controls.Add(Me.lblChucDanh)
        Me.UltraTabPageControl1.Controls.Add(Me.para_ChucDanh)
        Me.UltraTabPageControl1.Controls.Add(Me.lblsectioncode)
        Me.UltraTabPageControl1.Controls.Add(Me.para_teamcode)
        Me.UltraTabPageControl1.Controls.Add(Me.lblteamcode)
        Me.UltraTabPageControl1.Controls.Add(Me.para_sectioncode)
        Me.UltraTabPageControl1.Controls.Add(Me.lbldepartmentcode)
        Me.UltraTabPageControl1.Controls.Add(Me.para_departmentcode)
        Me.UltraTabPageControl1.Controls.Add(Me.lblPosition_ID)
        Me.UltraTabPageControl1.Controls.Add(Me.para_Position_ID)
        Me.UltraTabPageControl1.Controls.Add(Me.lblPositionCategory_ID)
        Me.UltraTabPageControl1.Controls.Add(Me.para_PositionCategory_ID)
        Me.UltraTabPageControl1.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl1.Name = "UltraTabPageControl1"
        Me.UltraTabPageControl1.Size = New System.Drawing.Size(508, 197)
        '
        'btnXoa
        '
        Me.btnXoa.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnXoa.Location = New System.Drawing.Point(422, 42)
        Me.btnXoa.Name = "btnXoa"
        Me.btnXoa.Size = New System.Drawing.Size(62, 23)
        Me.btnXoa.TabIndex = 1251
        Me.btnXoa.Text = "Xóa"
        Me.btnXoa.VisualStyle = Janus.Windows.UI.VisualStyle.Office2003
        '
        'lblChooseAll
        '
        Me.lblChooseAll.BackColor = System.Drawing.Color.Transparent
        Me.lblChooseAll.Location = New System.Drawing.Point(36, 12)
        Me.lblChooseAll.Name = "lblChooseAll"
        Me.lblChooseAll.Size = New System.Drawing.Size(73, 15)
        Me.lblChooseAll.TabIndex = 1250
        Me.lblChooseAll.Text = "Lọc toàn bộ"
        Me.lblChooseAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'para_Position
        '
        Me.para_Position.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_Position.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_Position.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout1.LayoutString = resources.GetString("GridEXLayout1.LayoutString")
        Me.para_Position.DesignTimeLayout = GridEXLayout1
        Me.para_Position.DisplayMember = "Name"
        Me.para_Position.Location = New System.Drawing.Point(131, 12)
        Me.para_Position.Name = "para_Position"
        Me.para_Position.SelectedItem = Nothing
        Me.para_Position.Size = New System.Drawing.Size(353, 20)
        Me.para_Position.TabIndex = 1249
        Me.para_Position.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_Position.Value = Nothing
        Me.para_Position.ValueMember = "Code"
        '
        'lblFactory_ID
        '
        Me.lblFactory_ID.BackColor = System.Drawing.Color.Transparent
        Me.lblFactory_ID.Location = New System.Drawing.Point(36, 50)
        Me.lblFactory_ID.Name = "lblFactory_ID"
        Me.lblFactory_ID.Size = New System.Drawing.Size(73, 15)
        Me.lblFactory_ID.TabIndex = 1248
        Me.lblFactory_ID.Text = "Phòng ban"
        Me.lblFactory_ID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'para_Factory_ID
        '
        Me.para_Factory_ID.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_Factory_ID.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_Factory_ID.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout2.LayoutString = resources.GetString("GridEXLayout2.LayoutString")
        Me.para_Factory_ID.DesignTimeLayout = GridEXLayout2
        Me.para_Factory_ID.DisplayMember = "Name"
        Me.para_Factory_ID.Enabled = False
        Me.para_Factory_ID.Location = New System.Drawing.Point(131, 45)
        Me.para_Factory_ID.Name = "para_Factory_ID"
        Me.para_Factory_ID.SelectedItem = Nothing
        Me.para_Factory_ID.Size = New System.Drawing.Size(285, 20)
        Me.para_Factory_ID.TabIndex = 1
        Me.para_Factory_ID.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_Factory_ID.Value = Nothing
        Me.para_Factory_ID.ValueMember = "Code"
        '
        'lblChucDanh
        '
        Me.lblChucDanh.BackColor = System.Drawing.Color.Transparent
        Me.lblChucDanh.Location = New System.Drawing.Point(444, 173)
        Me.lblChucDanh.Name = "lblChucDanh"
        Me.lblChucDanh.Size = New System.Drawing.Size(10, 19)
        Me.lblChucDanh.TabIndex = 1199
        Me.lblChucDanh.Text = "Chức danh"
        Me.lblChucDanh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblChucDanh.Visible = False
        '
        'para_ChucDanh
        '
        Me.para_ChucDanh.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_ChucDanh.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_ChucDanh.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout3.LayoutString = resources.GetString("GridEXLayout3.LayoutString")
        Me.para_ChucDanh.DesignTimeLayout = GridEXLayout3
        Me.para_ChucDanh.DisplayMember = "TenChucDanh"
        Me.para_ChucDanh.ImageVerticalAlignment = Janus.Windows.GridEX.ImageVerticalAlignment.Near
        Me.para_ChucDanh.Location = New System.Drawing.Point(485, 177)
        Me.para_ChucDanh.Name = "para_ChucDanh"
        Me.para_ChucDanh.SelectedItem = Nothing
        Me.para_ChucDanh.Size = New System.Drawing.Size(14, 20)
        Me.para_ChucDanh.TabIndex = 13
        Me.para_ChucDanh.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_ChucDanh.Value = Nothing
        Me.para_ChucDanh.ValueMember = "TenChucDanh"
        Me.para_ChucDanh.Visible = False
        '
        'lblsectioncode
        '
        Me.lblsectioncode.BackColor = System.Drawing.Color.Transparent
        Me.lblsectioncode.Location = New System.Drawing.Point(36, 97)
        Me.lblsectioncode.Name = "lblsectioncode"
        Me.lblsectioncode.Size = New System.Drawing.Size(73, 15)
        Me.lblsectioncode.TabIndex = 153
        Me.lblsectioncode.Text = "Nhóm"
        Me.lblsectioncode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'para_teamcode
        '
        Me.para_teamcode.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_teamcode.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_teamcode.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout4.LayoutString = resources.GetString("GridEXLayout4.LayoutString")
        Me.para_teamcode.DesignTimeLayout = GridEXLayout4
        Me.para_teamcode.DisplayMember = "Name"
        Me.para_teamcode.ImageVerticalAlignment = Janus.Windows.GridEX.ImageVerticalAlignment.Near
        Me.para_teamcode.Location = New System.Drawing.Point(131, 118)
        Me.para_teamcode.Name = "para_teamcode"
        Me.para_teamcode.SelectedItem = Nothing
        Me.para_teamcode.Size = New System.Drawing.Size(285, 20)
        Me.para_teamcode.TabIndex = 7
        Me.para_teamcode.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_teamcode.Value = Nothing
        Me.para_teamcode.ValueMember = "Code"
        '
        'lblteamcode
        '
        Me.lblteamcode.BackColor = System.Drawing.Color.Transparent
        Me.lblteamcode.Location = New System.Drawing.Point(36, 121)
        Me.lblteamcode.Name = "lblteamcode"
        Me.lblteamcode.Size = New System.Drawing.Size(73, 15)
        Me.lblteamcode.TabIndex = 152
        Me.lblteamcode.Text = "Tổ"
        Me.lblteamcode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'para_sectioncode
        '
        Me.para_sectioncode.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_sectioncode.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_sectioncode.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout5.LayoutString = resources.GetString("GridEXLayout5.LayoutString")
        Me.para_sectioncode.DesignTimeLayout = GridEXLayout5
        Me.para_sectioncode.DisplayMember = "Name"
        Me.para_sectioncode.ImageVerticalAlignment = Janus.Windows.GridEX.ImageVerticalAlignment.Near
        Me.para_sectioncode.Location = New System.Drawing.Point(131, 94)
        Me.para_sectioncode.Name = "para_sectioncode"
        Me.para_sectioncode.SelectedItem = Nothing
        Me.para_sectioncode.Size = New System.Drawing.Size(285, 20)
        Me.para_sectioncode.TabIndex = 5
        Me.para_sectioncode.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_sectioncode.Value = Nothing
        Me.para_sectioncode.ValueMember = "Code"
        '
        'lbldepartmentcode
        '
        Me.lbldepartmentcode.BackColor = System.Drawing.Color.Transparent
        Me.lbldepartmentcode.Location = New System.Drawing.Point(36, 73)
        Me.lbldepartmentcode.Name = "lbldepartmentcode"
        Me.lbldepartmentcode.Size = New System.Drawing.Size(73, 15)
        Me.lbldepartmentcode.TabIndex = 151
        Me.lbldepartmentcode.Text = "Bộ phận"
        Me.lbldepartmentcode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'para_departmentcode
        '
        Me.para_departmentcode.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_departmentcode.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_departmentcode.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout6.LayoutString = resources.GetString("GridEXLayout6.LayoutString")
        Me.para_departmentcode.DesignTimeLayout = GridEXLayout6
        Me.para_departmentcode.DisplayMember = "Name"
        Me.para_departmentcode.Location = New System.Drawing.Point(131, 70)
        Me.para_departmentcode.Name = "para_departmentcode"
        Me.para_departmentcode.SelectedItem = Nothing
        Me.para_departmentcode.Size = New System.Drawing.Size(285, 20)
        Me.para_departmentcode.TabIndex = 3
        Me.para_departmentcode.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_departmentcode.Value = Nothing
        Me.para_departmentcode.ValueMember = "Code"
        '
        'lblPosition_ID
        '
        Me.lblPosition_ID.BackColor = System.Drawing.Color.Transparent
        Me.lblPosition_ID.Location = New System.Drawing.Point(36, 147)
        Me.lblPosition_ID.Name = "lblPosition_ID"
        Me.lblPosition_ID.Size = New System.Drawing.Size(75, 19)
        Me.lblPosition_ID.TabIndex = 150
        Me.lblPosition_ID.Text = "Chức vụ"
        Me.lblPosition_ID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblPosition_ID.Visible = False
        '
        'para_Position_ID
        '
        Me.para_Position_ID.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_Position_ID.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_Position_ID.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout7.LayoutString = resources.GetString("GridEXLayout7.LayoutString")
        Me.para_Position_ID.DesignTimeLayout = GridEXLayout7
        Me.para_Position_ID.DisplayMember = "Position_ID"
        Me.para_Position_ID.ImageVerticalAlignment = Janus.Windows.GridEX.ImageVerticalAlignment.Near
        Me.para_Position_ID.Location = New System.Drawing.Point(131, 147)
        Me.para_Position_ID.Name = "para_Position_ID"
        Me.para_Position_ID.SelectedItem = Nothing
        Me.para_Position_ID.Size = New System.Drawing.Size(285, 20)
        Me.para_Position_ID.TabIndex = 9
        Me.para_Position_ID.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_Position_ID.Value = Nothing
        Me.para_Position_ID.ValueMember = "Position_ID"
        Me.para_Position_ID.Visible = False
        '
        'lblPositionCategory_ID
        '
        Me.lblPositionCategory_ID.BackColor = System.Drawing.Color.Transparent
        Me.lblPositionCategory_ID.Location = New System.Drawing.Point(445, 147)
        Me.lblPositionCategory_ID.Name = "lblPositionCategory_ID"
        Me.lblPositionCategory_ID.Size = New System.Drawing.Size(10, 19)
        Me.lblPositionCategory_ID.TabIndex = 147
        Me.lblPositionCategory_ID.Text = "Loại chức vụ"
        Me.lblPositionCategory_ID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblPositionCategory_ID.Visible = False
        '
        'para_PositionCategory_ID
        '
        Me.para_PositionCategory_ID.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_PositionCategory_ID.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_PositionCategory_ID.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout8.LayoutString = resources.GetString("GridEXLayout8.LayoutString")
        Me.para_PositionCategory_ID.DesignTimeLayout = GridEXLayout8
        Me.para_PositionCategory_ID.DisplayMember = "PositionCategory_ID"
        Me.para_PositionCategory_ID.ImageVerticalAlignment = Janus.Windows.GridEX.ImageVerticalAlignment.Near
        Me.para_PositionCategory_ID.Location = New System.Drawing.Point(485, 151)
        Me.para_PositionCategory_ID.Name = "para_PositionCategory_ID"
        Me.para_PositionCategory_ID.SelectedItem = Nothing
        Me.para_PositionCategory_ID.Size = New System.Drawing.Size(14, 20)
        Me.para_PositionCategory_ID.TabIndex = 11
        Me.para_PositionCategory_ID.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_PositionCategory_ID.Value = Nothing
        Me.para_PositionCategory_ID.ValueMember = "PositionCategory_ID"
        Me.para_PositionCategory_ID.Visible = False
        '
        'UltraTabPageControl2
        '
        Me.UltraTabPageControl2.Controls.Add(Me.para_fromdate)
        Me.UltraTabPageControl2.Controls.Add(Me.para_todate)
        Me.UltraTabPageControl2.Controls.Add(Me.lbltodate)
        Me.UltraTabPageControl2.Controls.Add(Me.lblfromdate)
        Me.UltraTabPageControl2.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl2.Name = "UltraTabPageControl2"
        Me.UltraTabPageControl2.Size = New System.Drawing.Size(508, 197)
        '
        'para_fromdate
        '
        Me.para_fromdate.CustomFormat = "dd/MM/yyyy"
        Me.para_fromdate.DateFormat = Janus.Windows.CalendarCombo.DateFormat.Custom
        '
        '
        '
        Me.para_fromdate.DropDownCalendar.FirstMonth = New Date(2018, 10, 1, 0, 0, 0, 0)
        Me.para_fromdate.DropDownCalendar.Location = New System.Drawing.Point(0, 0)
        Me.para_fromdate.DropDownCalendar.Name = ""
        Me.para_fromdate.DropDownCalendar.Size = New System.Drawing.Size(164, 167)
        Me.para_fromdate.DropDownCalendar.TabIndex = 0
        Me.para_fromdate.DropDownCalendar.VisualStyle = Janus.Windows.CalendarCombo.VisualStyle.Standard
        Me.para_fromdate.Location = New System.Drawing.Point(168, 40)
        Me.para_fromdate.Name = "para_fromdate"
        Me.para_fromdate.Size = New System.Drawing.Size(104, 20)
        Me.para_fromdate.TabIndex = 168
        Me.para_fromdate.Value = New Date(2010, 3, 20, 0, 0, 0, 0)
        '
        'para_todate
        '
        Me.para_todate.CustomFormat = "dd/MM/yyyy"
        Me.para_todate.DateFormat = Janus.Windows.CalendarCombo.DateFormat.Custom
        '
        '
        '
        Me.para_todate.DropDownCalendar.FirstMonth = New Date(2018, 10, 1, 0, 0, 0, 0)
        Me.para_todate.DropDownCalendar.Location = New System.Drawing.Point(0, 0)
        Me.para_todate.DropDownCalendar.Name = ""
        Me.para_todate.DropDownCalendar.Size = New System.Drawing.Size(164, 167)
        Me.para_todate.DropDownCalendar.TabIndex = 0
        Me.para_todate.DropDownCalendar.VisualStyle = Janus.Windows.CalendarCombo.VisualStyle.Standard
        Me.para_todate.Location = New System.Drawing.Point(168, 64)
        Me.para_todate.Name = "para_todate"
        Me.para_todate.Size = New System.Drawing.Size(104, 20)
        Me.para_todate.TabIndex = 169
        Me.para_todate.Value = New Date(2010, 3, 20, 0, 0, 0, 0)
        '
        'lbltodate
        '
        Me.lbltodate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltodate.Location = New System.Drawing.Point(104, 64)
        Me.lbltodate.Name = "lbltodate"
        Me.lbltodate.Size = New System.Drawing.Size(56, 20)
        Me.lbltodate.TabIndex = 170
        Me.lbltodate.Text = "Đến ngày"
        Me.lbltodate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblfromdate
        '
        Me.lblfromdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfromdate.Location = New System.Drawing.Point(104, 40)
        Me.lblfromdate.Name = "lblfromdate"
        Me.lblfromdate.Size = New System.Drawing.Size(64, 20)
        Me.lblfromdate.TabIndex = 171
        Me.lblfromdate.Text = "Từ ngày"
        Me.lblfromdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'UltraTabPageControl3
        '
        Me.UltraTabPageControl3.Controls.Add(Me.para_Ngay)
        Me.UltraTabPageControl3.Controls.Add(Me.lblNgay)
        Me.UltraTabPageControl3.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl3.Name = "UltraTabPageControl3"
        Me.UltraTabPageControl3.Size = New System.Drawing.Size(508, 197)
        '
        'para_Ngay
        '
        Me.para_Ngay.CustomFormat = "dd/MM/yyyy"
        Me.para_Ngay.DateFormat = Janus.Windows.CalendarCombo.DateFormat.Custom
        '
        '
        '
        Me.para_Ngay.DropDownCalendar.FirstMonth = New Date(2018, 10, 1, 0, 0, 0, 0)
        Me.para_Ngay.DropDownCalendar.Location = New System.Drawing.Point(0, 0)
        Me.para_Ngay.DropDownCalendar.Name = ""
        Me.para_Ngay.DropDownCalendar.Size = New System.Drawing.Size(164, 167)
        Me.para_Ngay.DropDownCalendar.TabIndex = 0
        Me.para_Ngay.DropDownCalendar.VisualStyle = Janus.Windows.CalendarCombo.VisualStyle.Standard
        Me.para_Ngay.Location = New System.Drawing.Point(168, 48)
        Me.para_Ngay.Name = "para_Ngay"
        Me.para_Ngay.Size = New System.Drawing.Size(104, 20)
        Me.para_Ngay.TabIndex = 172
        Me.para_Ngay.Value = New Date(2010, 3, 20, 0, 0, 0, 0)
        '
        'lblNgay
        '
        Me.lblNgay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNgay.Location = New System.Drawing.Point(104, 48)
        Me.lblNgay.Name = "lblNgay"
        Me.lblNgay.Size = New System.Drawing.Size(64, 20)
        Me.lblNgay.TabIndex = 173
        Me.lblNgay.Text = "Ngày"
        Me.lblNgay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'UltraTabPageControl4
        '
        Me.UltraTabPageControl4.Controls.Add(Me.para_Year)
        Me.UltraTabPageControl4.Controls.Add(Me.para_Month)
        Me.UltraTabPageControl4.Controls.Add(Me.lblMonth_)
        Me.UltraTabPageControl4.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl4.Name = "UltraTabPageControl4"
        Me.UltraTabPageControl4.Size = New System.Drawing.Size(508, 197)
        '
        'para_Year
        '
        Me.para_Year.Location = New System.Drawing.Point(178, 57)
        Me.para_Year.Name = "para_Year"
        Me.para_Year.Size = New System.Drawing.Size(56, 20)
        Me.para_Year.TabIndex = 226
        '
        'para_Month
        '
        Me.para_Month.Location = New System.Drawing.Point(126, 57)
        Me.para_Month.Name = "para_Month"
        Me.para_Month.Size = New System.Drawing.Size(40, 20)
        Me.para_Month.TabIndex = 225
        '
        'lblMonth_
        '
        Me.lblMonth_.Location = New System.Drawing.Point(56, 56)
        Me.lblMonth_.Name = "lblMonth_"
        Me.lblMonth_.Size = New System.Drawing.Size(64, 23)
        Me.lblMonth_.TabIndex = 224
        Me.lblMonth_.Text = "Tháng"
        '
        'UltraTabPageControl5
        '
        Me.UltraTabPageControl5.Controls.Add(Me.lblType)
        Me.UltraTabPageControl5.Controls.Add(Me.para_TypeOfContract)
        Me.UltraTabPageControl5.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl5.Name = "UltraTabPageControl5"
        Me.UltraTabPageControl5.Size = New System.Drawing.Size(508, 197)
        '
        'lblType
        '
        Me.lblType.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.Location = New System.Drawing.Point(40, 64)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(104, 20)
        Me.lblType.TabIndex = 304
        Me.lblType.Text = "Loại HĐ"
        Me.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'para_TypeOfContract
        '
        Me.para_TypeOfContract.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_TypeOfContract.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_TypeOfContract.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout9.LayoutString = resources.GetString("GridEXLayout9.LayoutString")
        Me.para_TypeOfContract.DesignTimeLayout = GridEXLayout9
        Me.para_TypeOfContract.DisplayMember = "Contract_ID"
        Me.para_TypeOfContract.Location = New System.Drawing.Point(160, 64)
        Me.para_TypeOfContract.Name = "para_TypeOfContract"
        Me.para_TypeOfContract.SelectedItem = Nothing
        Me.para_TypeOfContract.Size = New System.Drawing.Size(172, 20)
        Me.para_TypeOfContract.TabIndex = 303
        Me.para_TypeOfContract.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_TypeOfContract.Value = Nothing
        Me.para_TypeOfContract.ValueMember = "Contract_ID"
        '
        'UltraTabPageControl6
        '
        Me.UltraTabPageControl6.Controls.Add(Me.para_DanhSachKey)
        Me.UltraTabPageControl6.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl6.Name = "UltraTabPageControl6"
        Me.UltraTabPageControl6.Size = New System.Drawing.Size(508, 197)
        '
        'para_DanhSachKey
        '
        Me.para_DanhSachKey.Location = New System.Drawing.Point(72, 24)
        Me.para_DanhSachKey.Name = "para_DanhSachKey"
        Me.para_DanhSachKey.Size = New System.Drawing.Size(240, 112)
        Me.para_DanhSachKey.TabIndex = 0
        Me.para_DanhSachKey.Text = ""
        '
        'UltraTabPageControl7
        '
        Me.UltraTabPageControl7.Controls.Add(Me.gridDanhSachNhanVien)
        Me.UltraTabPageControl7.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl7.Name = "UltraTabPageControl7"
        Me.UltraTabPageControl7.Size = New System.Drawing.Size(508, 197)
        '
        'gridDanhSachNhanVien
        '
        Me.gridDanhSachNhanVien.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout10.LayoutString = resources.GetString("GridEXLayout10.LayoutString")
        Me.gridDanhSachNhanVien.DesignTimeLayout = GridEXLayout10
        Me.gridDanhSachNhanVien.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gridDanhSachNhanVien.EditorsControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        Me.gridDanhSachNhanVien.FilterMode = Janus.Windows.GridEX.FilterMode.Automatic
        Me.gridDanhSachNhanVien.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gridDanhSachNhanVien.Location = New System.Drawing.Point(0, 0)
        Me.gridDanhSachNhanVien.Name = "gridDanhSachNhanVien"
        Me.gridDanhSachNhanVien.RecordNavigator = True
        Me.gridDanhSachNhanVien.Size = New System.Drawing.Size(508, 197)
        Me.gridDanhSachNhanVien.TabIndex = 11
        '
        'UltraTabPageControl8
        '
        Me.UltraTabPageControl8.Controls.Add(Me.lblnationality)
        Me.UltraTabPageControl8.Controls.Add(Me.para_nationality)
        Me.UltraTabPageControl8.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl8.Name = "UltraTabPageControl8"
        Me.UltraTabPageControl8.Size = New System.Drawing.Size(508, 197)
        '
        'lblnationality
        '
        Me.lblnationality.BackColor = System.Drawing.Color.Transparent
        Me.lblnationality.Location = New System.Drawing.Point(48, 69)
        Me.lblnationality.Name = "lblnationality"
        Me.lblnationality.Size = New System.Drawing.Size(112, 19)
        Me.lblnationality.TabIndex = 82
        Me.lblnationality.Text = "Quốc tịch"
        Me.lblnationality.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'para_nationality
        '
        Me.para_nationality.AutoComplete = True
        Me.para_nationality.AutoSize = True
        Me.para_nationality.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem1.DataValue = "ValueListItem0"
        ValueListItem1.DisplayText = "Vietnamese"
        ValueListItem2.DataValue = "ValueListItem1"
        ValueListItem2.DisplayText = "Non-Vietnamese"
        Me.para_nationality.Items.Add(ValueListItem1)
        Me.para_nationality.Items.Add(ValueListItem2)
        Me.para_nationality.Location = New System.Drawing.Point(168, 69)
        Me.para_nationality.Name = "para_nationality"
        Me.para_nationality.Size = New System.Drawing.Size(212, 21)
        Me.para_nationality.TabIndex = 81
        '
        'UltraTabPageControl9
        '
        Me.UltraTabPageControl9.Controls.Add(Me.para_SalaryTable)
        Me.UltraTabPageControl9.Controls.Add(Me.lblSalaryTable)
        Me.UltraTabPageControl9.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl9.Name = "UltraTabPageControl9"
        Me.UltraTabPageControl9.Size = New System.Drawing.Size(508, 197)
        '
        'para_SalaryTable
        '
        Me.para_SalaryTable.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.para_SalaryTable.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.para_SalaryTable.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout11.LayoutString = resources.GetString("GridEXLayout11.LayoutString")
        Me.para_SalaryTable.DesignTimeLayout = GridEXLayout11
        Me.para_SalaryTable.DisplayMember = "NameVN"
        Me.para_SalaryTable.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.para_SalaryTable.ImageVerticalAlignment = Janus.Windows.GridEX.ImageVerticalAlignment.Near
        Me.para_SalaryTable.Location = New System.Drawing.Point(176, 70)
        Me.para_SalaryTable.Name = "para_SalaryTable"
        Me.para_SalaryTable.SelectedItem = Nothing
        Me.para_SalaryTable.Size = New System.Drawing.Size(160, 20)
        Me.para_SalaryTable.TabIndex = 211
        Me.para_SalaryTable.TextAlignment = Janus.Windows.GridEX.TextAlignment.Near
        Me.para_SalaryTable.Value = Nothing
        Me.para_SalaryTable.ValueMember = "Code"
        '
        'lblSalaryTable
        '
        Me.lblSalaryTable.BackColor = System.Drawing.Color.Transparent
        Me.lblSalaryTable.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalaryTable.Location = New System.Drawing.Point(88, 70)
        Me.lblSalaryTable.Name = "lblSalaryTable"
        Me.lblSalaryTable.Size = New System.Drawing.Size(80, 19)
        Me.lblSalaryTable.TabIndex = 210
        Me.lblSalaryTable.Text = "Bảng lương"
        Me.lblSalaryTable.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'UltraTabPageControl10
        '
        Me.UltraTabPageControl10.Controls.Add(Me.para_year_)
        Me.UltraTabPageControl10.Controls.Add(Me.lblYear_)
        Me.UltraTabPageControl10.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabPageControl10.Name = "UltraTabPageControl10"
        Me.UltraTabPageControl10.Size = New System.Drawing.Size(508, 197)
        '
        'para_year_
        '
        Me.para_year_.Location = New System.Drawing.Point(161, 67)
        Me.para_year_.Name = "para_year_"
        Me.para_year_.Size = New System.Drawing.Size(56, 20)
        Me.para_year_.TabIndex = 228
        '
        'lblYear_
        '
        Me.lblYear_.Location = New System.Drawing.Point(91, 67)
        Me.lblYear_.Name = "lblYear_"
        Me.lblYear_.Size = New System.Drawing.Size(64, 21)
        Me.lblYear_.TabIndex = 227
        Me.lblYear_.Text = "Năm"
        '
        'UltraTabPageControl11
        '
        Me.UltraTabPageControl11.Controls.Add(Me.para_LeaveType)
        Me.UltraTabPageControl11.Location = New System.Drawing.Point(1, 23)
        Me.UltraTabPageControl11.Name = "UltraTabPageControl11"
        Me.UltraTabPageControl11.Size = New System.Drawing.Size(508, 197)
        '
        'para_LeaveType
        '
        Me.para_LeaveType.ControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        GridEXLayout12.LayoutString = resources.GetString("GridEXLayout12.LayoutString")
        Me.para_LeaveType.DesignTimeLayout = GridEXLayout12
        Me.para_LeaveType.Dock = System.Windows.Forms.DockStyle.Fill
        Me.para_LeaveType.EditorsControlStyle.ButtonAppearance = Janus.Windows.GridEX.ButtonAppearance.Regular
        Me.para_LeaveType.FilterMode = Janus.Windows.GridEX.FilterMode.Automatic
        Me.para_LeaveType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.para_LeaveType.GroupByBoxVisible = False
        Me.para_LeaveType.Location = New System.Drawing.Point(0, 0)
        Me.para_LeaveType.Name = "para_LeaveType"
        Me.para_LeaveType.RecordNavigator = True
        Me.para_LeaveType.Size = New System.Drawing.Size(508, 197)
        Me.para_LeaveType.TabIndex = 12
        '
        'UltraTabSharedControlsPage1
        '
        Me.UltraTabSharedControlsPage1.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabSharedControlsPage1.Name = "UltraTabSharedControlsPage1"
        Me.UltraTabSharedControlsPage1.Size = New System.Drawing.Size(508, 197)
        '
        'UltraTabControl1
        '
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl1)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabSharedControlsPage1)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl2)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl3)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl4)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl5)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl6)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl7)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl8)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl9)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl10)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl11)
        Me.UltraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.UltraTabControl1.Name = "UltraTabControl1"
        Me.UltraTabControl1.SharedControlsPage = Me.UltraTabSharedControlsPage1
        Me.UltraTabControl1.Size = New System.Drawing.Size(512, 223)
        Me.UltraTabControl1.TabIndex = 12
        UltraTab1.Key = "ViTri"
        UltraTab1.TabPage = Me.UltraTabPageControl1
        UltraTab1.Text = "Vị trí"
        UltraTab1.Visible = False
        UltraTab2.Key = "TuNgayDenNgay"
        UltraTab2.TabPage = Me.UltraTabPageControl2
        UltraTab2.Text = "Từ ngày đến ngày"
        UltraTab2.Visible = False
        UltraTab3.Key = "Ngay"
        UltraTab3.TabPage = Me.UltraTabPageControl3
        UltraTab3.Text = "Ngày"
        UltraTab3.Visible = False
        UltraTab4.Key = "Thang"
        UltraTab4.TabPage = Me.UltraTabPageControl4
        UltraTab4.Text = "Tháng"
        UltraTab4.Visible = False
        UltraTab5.Key = "LoaiHD"
        UltraTab5.TabPage = Me.UltraTabPageControl5
        UltraTab5.Text = "Loại HĐ"
        UltraTab5.Visible = False
        UltraTab6.Key = "DanhSachKey"
        UltraTab6.TabPage = Me.UltraTabPageControl6
        UltraTab6.Text = "Danh sách key"
        UltraTab6.Visible = False
        UltraTab7.Key = "DSNhanVien"
        UltraTab7.TabPage = Me.UltraTabPageControl7
        UltraTab7.Text = "DS nhân viên"
        UltraTab7.Visible = False
        UltraTab8.Key = "nationality"
        UltraTab8.TabPage = Me.UltraTabPageControl8
        UltraTab8.Text = "Quốc tịch"
        UltraTab8.Visible = False
        UltraTab9.Key = "SalaryTable"
        UltraTab9.TabPage = Me.UltraTabPageControl9
        UltraTab9.Text = "Bảng lương"
        UltraTab9.Visible = False
        UltraTab10.Key = "Nam"
        UltraTab10.TabPage = Me.UltraTabPageControl10
        UltraTab10.Text = "Năm"
        UltraTab10.Visible = False
        UltraTab11.Key = "LeaveType"
        UltraTab11.TabPage = Me.UltraTabPageControl11
        UltraTab11.Text = "Danh mục phép"
        UltraTab11.Visible = False
        Me.UltraTabControl1.Tabs.AddRange(New Infragistics.Win.UltraWinTabControl.UltraTab() {UltraTab1, UltraTab2, UltraTab3, UltraTab4, UltraTab5, UltraTab6, UltraTab7, UltraTab8, UltraTab9, UltraTab10, UltraTab11})
        '
        'btnOk
        '
        Me.btnOk.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOk.Location = New System.Drawing.Point(184, 398)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(80, 23)
        Me.btnOk.TabIndex = 1000
        Me.btnOk.Text = "Ok"
        Me.btnOk.VisualStyle = Janus.Windows.UI.VisualStyle.Office2003
        '
        'gbLuaChonHienThi
        '
        Me.gbLuaChonHienThi.Controls.Add(Me.ExportDocumentFile)
        Me.gbLuaChonHienThi.Controls.Add(Me.PrinViewDocument)
        Me.gbLuaChonHienThi.Controls.Add(Me.ExecStore)
        Me.gbLuaChonHienThi.Controls.Add(Me.InputTemplateFile)
        Me.gbLuaChonHienThi.Controls.Add(Me.GetTemplateFile)
        Me.gbLuaChonHienThi.Controls.Add(Me.PrintView)
        Me.gbLuaChonHienThi.Controls.Add(Me.ExportExcel)
        Me.gbLuaChonHienThi.Controls.Add(Me.ViewOnGrid)
        Me.gbLuaChonHienThi.Location = New System.Drawing.Point(0, 229)
        Me.gbLuaChonHienThi.Name = "gbLuaChonHienThi"
        Me.gbLuaChonHienThi.Size = New System.Drawing.Size(509, 120)
        Me.gbLuaChonHienThi.TabIndex = 56
        Me.gbLuaChonHienThi.TabStop = False
        Me.gbLuaChonHienThi.Text = "Lựa chọn thực hiện"
        '
        'ExportDocumentFile
        '
        Me.ExportDocumentFile.Enabled = False
        Me.ExportDocumentFile.Location = New System.Drawing.Point(184, 86)
        Me.ExportDocumentFile.Name = "ExportDocumentFile"
        Me.ExportDocumentFile.Size = New System.Drawing.Size(128, 24)
        Me.ExportDocumentFile.TabIndex = 182
        Me.ExportDocumentFile.Text = "Xuất file(Văn bản)"
        '
        'PrinViewDocument
        '
        Me.PrinViewDocument.Enabled = False
        Me.PrinViewDocument.Location = New System.Drawing.Point(8, 88)
        Me.PrinViewDocument.Name = "PrinViewDocument"
        Me.PrinViewDocument.Size = New System.Drawing.Size(128, 24)
        Me.PrinViewDocument.TabIndex = 181
        Me.PrinViewDocument.Text = "Xem file in (Văn bản)"
        '
        'ExecStore
        '
        Me.ExecStore.Enabled = False
        Me.ExecStore.Location = New System.Drawing.Point(360, 56)
        Me.ExecStore.Name = "ExecStore"
        Me.ExecStore.Size = New System.Drawing.Size(96, 24)
        Me.ExecStore.TabIndex = 180
        Me.ExecStore.Text = "Thực hiện lệnh"
        '
        'InputTemplateFile
        '
        Me.InputTemplateFile.Enabled = False
        Me.InputTemplateFile.Location = New System.Drawing.Point(184, 56)
        Me.InputTemplateFile.Name = "InputTemplateFile"
        Me.InputTemplateFile.Size = New System.Drawing.Size(104, 24)
        Me.InputTemplateFile.TabIndex = 179
        Me.InputTemplateFile.Text = "Nhập Template"
        '
        'GetTemplateFile
        '
        Me.GetTemplateFile.Enabled = False
        Me.GetTemplateFile.Location = New System.Drawing.Point(8, 56)
        Me.GetTemplateFile.Name = "GetTemplateFile"
        Me.GetTemplateFile.Size = New System.Drawing.Size(112, 24)
        Me.GetTemplateFile.TabIndex = 178
        Me.GetTemplateFile.Text = "Lấy Template"
        '
        'PrintView
        '
        Me.PrintView.Enabled = False
        Me.PrintView.Location = New System.Drawing.Point(360, 24)
        Me.PrintView.Name = "PrintView"
        Me.PrintView.Size = New System.Drawing.Size(96, 24)
        Me.PrintView.TabIndex = 177
        Me.PrintView.Text = "Xem file in"
        '
        'ExportExcel
        '
        Me.ExportExcel.Enabled = False
        Me.ExportExcel.Location = New System.Drawing.Point(184, 24)
        Me.ExportExcel.Name = "ExportExcel"
        Me.ExportExcel.Size = New System.Drawing.Size(96, 24)
        Me.ExportExcel.TabIndex = 176
        Me.ExportExcel.Text = "Xuất Excel"
        '
        'ViewOnGrid
        '
        Me.ViewOnGrid.Enabled = False
        Me.ViewOnGrid.Location = New System.Drawing.Point(8, 24)
        Me.ViewOnGrid.Name = "ViewOnGrid"
        Me.ViewOnGrid.Size = New System.Drawing.Size(96, 24)
        Me.ViewOnGrid.TabIndex = 175
        Me.ViewOnGrid.Text = "Xem trên lưới"
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(272, 398)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(80, 23)
        Me.btnCancel.TabIndex = 1005
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.VisualStyle = Janus.Windows.UI.VisualStyle.Office2003
        '
        'frmPara
        '
        Me.AcceptButton = Me.btnOk
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(512, 432)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.gbLuaChonHienThi)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.UltraTabControl1)
        Me.Name = "frmPara"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmPara"
        Me.UltraTabPageControl1.ResumeLayout(False)
        Me.UltraTabPageControl2.ResumeLayout(False)
        Me.UltraTabPageControl3.ResumeLayout(False)
        Me.UltraTabPageControl4.ResumeLayout(False)
        Me.UltraTabPageControl5.ResumeLayout(False)
        Me.UltraTabPageControl6.ResumeLayout(False)
        Me.UltraTabPageControl7.ResumeLayout(False)
        CType(Me.gridDanhSachNhanVien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl8.ResumeLayout(False)
        CType(Me.para_nationality, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabPageControl9.ResumeLayout(False)
        Me.UltraTabPageControl10.ResumeLayout(False)
        Me.UltraTabPageControl11.ResumeLayout(False)
        CType(Me.para_LeaveType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UltraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabControl1.ResumeLayout(False)
        Me.gbLuaChonHienThi.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmPara_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim tabLoaiHD As DataTable = kn.ReadData("select * from SmartBooks_Contract", "table")
        para_TypeOfContract.DataSource = tabLoaiHD
        'Lay quyen truy xuat
        tabQuyenTX = kn.ReadData("select * from [User] where UserName='" + obj.UserName + "'", "table")
        If Not IsDBNull(tabQuyenTX.Rows(0)("QuyenTruyXuat")) Then
            para_Position.DataSource = kn.ReadData("select * from udf_Position('" + obj.Lan + "',0) where code in ('" + tabQuyenTX.Rows(0)("QuyenTruyXuat").ToString.Replace(",", "','") + "')", "table")
        Else
            para_Position.DataSource = kn.ReadData("select * from udf_Position('" + obj.Lan + "',0)", "table")
        End If
        'load bảng loại phép
        para_LeaveType.DataSource = kn.ReadData("select Leavetype_ID as Code, LeaveType_" + obj.Lan + " as Name from smartbooks_leavetype", "table")
        'Load bảng lương
        para_SalaryTable.DataSource = kn.ReadData("select * from HR_SalaryTable", "table")
        If obj.Lan = "EN" Then
            para_SalaryTable.DisplayMember = "NameEN"
        ElseIf obj.Lan = "VN" Then
            para_SalaryTable.DisplayMember = "NameVN"
        Else
            para_SalaryTable.DisplayMember = "NameKR"
        End If
        'Lưu giá trị lên biến chung
        Me.para_fromdate.Value = obj.PARA_FROMDATE
        Me.para_todate.Value = obj.PARA_TODATE
        Me.para_Ngay.Value = obj.PARA_NGAY
        Try
            Me.para_Month.Text = obj.PARA_MONTH.ToString
            Me.para_Year.Text = obj.PARA_YEAR.ToString
            Me.para_year_.Text = obj.PARA_YEAR_.ToString
        Catch ex As Exception

        End Try
        Me.para_TypeOfContract.Value = obj.PARA_TYPEOFCONTRACT
        Me.para_Factory_ID.DataSource = kn.ReadData("select * from [dbo].[udf_Factory]('" + obj.Lan + "')", "table")
        If obj.PARA_FACTORY_ID = String.Empty Then
            Me.para_Factory_ID.Value = DBNull.Value
        Else
            Me.para_Factory_ID.Value = obj.PARA_FACTORY_ID
        End If
        If obj.PARA_DEPARTMENTCODE = String.Empty Then
            Me.para_departmentcode.Value = DBNull.Value
        Else
            Me.para_departmentcode.Value = obj.PARA_DEPARTMENTCODE
        End If
        If obj.PARA_SECTIONCODE = String.Empty Then
            Me.para_sectioncode.Value = DBNull.Value
        Else
            Me.para_sectioncode.Value = obj.PARA_SECTIONCODE
        End If
        If obj.PARA_TEAMCODE = String.Empty Then
            Me.para_teamcode.Value = DBNull.Value
        Else
            Me.para_teamcode.Value = obj.PARA_TEAMCODE
        End If
        Me.para_Position_ID.Value = obj.PARA_POSITION_ID
        Me.para_PositionCategory_ID.Value = obj.PARA_POSITIONCATEGORY_ID
        Me.para_nationality.Value = obj.PARA_NATIONALITY
        Me.para_SalaryTable.Value = obj.PARA_SALARYTABLE

        LoadLoaiReport()
        If Not IsDBNull(ReportInformation("Parameter")) Then
            For Each s As String In Split(ReportInformation("Parameter"), ",")
                LoadGiaoDien(s, Me)
            Next
        End If
        tvcn.ChangeLanguageToForm(Me, "")
    End Sub

    Private Sub LoadLoaiReport()
        For Each ct As Object In gbLuaChonHienThi.Controls
            Try
                If Not IsDBNull(ReportInformation(ct.Name)) Then
                    If ReportInformation(ct.Name) = True Then
                        ct.Enabled = True
                        ct.Checked = True
                    End If
                End If
            Catch ex As Exception

            End Try
        Next
    End Sub

    Private Sub LoadGiaoDien(ByVal ControlName As String, ByRef ParenControl As Control)
        Dim regex As Regex = New Regex("[0-9]+$")
        Dim match As Match = regex.Match(ParenControl.Name)
        Dim IndexOfTab As Integer = 0
        If match.Success Then
            IndexOfTab = CInt(match.Value) - 1
        End If
        If ParenControl.Name.ToUpper = ControlName.ToUpper Then
            UltraTabControl1.Tabs(IndexOfTab).Visible = True
        Else
            If ParenControl.Controls.Count >= 1 Then
                For Each ct As Control In ParenControl.Controls
                    If ct.Name.ToUpper = ControlName.ToUpper Then
                        UltraTabControl1.Tabs(IndexOfTab).Visible = True
                    Else
                        LoadGiaoDien(ControlName, ct)
                    End If
                Next
            End If
        End If
    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        obj.PARA_FROMDATE = para_fromdate.Value
        obj.PARA_TODATE = para_todate.Value
        obj.PARA_NGAY = para_Ngay.Value
        Try
            obj.PARA_MONTH = CInt(para_Month.Text)
            obj.PARA_YEAR = CInt(para_Year.Text)
            obj.PARA_YEAR_ = CInt(para_year_.Text)
        Catch ex As Exception

        End Try
        obj.PARA_TYPEOFCONTRACT = para_TypeOfContract.Value
        If Not IsDBNull(tabQuyenTX.Rows(0)("QuyenTruyXuat")) Then
            If IsDBNull(para_Factory_ID.Value) Or IsNothing(para_Factory_ID.Value) Then
                para_Factory_ID.Value = tabQuyenTX.Rows(0)("QuyenTruyXuat")
            End If
        End If

        If Not IsDBNull(para_Factory_ID.Value) Then
            obj.PARA_FACTORY_ID = para_Factory_ID.Value
        Else
            obj.PARA_FACTORY_ID = String.Empty
        End If

        If Not IsDBNull(para_departmentcode.Value) Then
            obj.PARA_DEPARTMENTCODE = para_departmentcode.Value
        Else
            obj.PARA_DEPARTMENTCODE = String.Empty
        End If
        If Not IsDBNull(para_sectioncode.Value) Then
            obj.PARA_SECTIONCODE = para_sectioncode.Value
        Else
            obj.PARA_SECTIONCODE = String.Empty
        End If
        If Not IsDBNull(para_teamcode.Value) Then
            obj.PARA_TEAMCODE = para_teamcode.Value
        Else
            obj.PARA_TEAMCODE = String.Empty
        End If
        obj.PARA_POSITION_ID = para_Position_ID.Value
        obj.PARA_POSITIONCATEGORY_ID = para_PositionCategory_ID.Value
        bViewOnGrid = ViewOnGrid.Checked
        bPrintView = PrintView.Checked
        bPrintViewDocument = PrinViewDocument.Checked
        If ExportExcel.Checked = True Then
            Dim bSaveData As Boolean, Excel_XoaDenDong As Integer, NotDeleteConfig As Boolean
            NotDeleteConfig = IIf(IsDBNull(ReportInformation("NotDeleteConfig")), False, ReportInformation("NotDeleteConfig"))
            If Not IsDBNull(ReportInformation("SaveData")) Then
                bSaveData = ReportInformation("SaveData")
            End If
            Dim bExportExcel As Boolean
            Dim bisOpen As Boolean = True
            Dim TemplateFile As String = ReportInformation("TemplateFile")
            If ExportExcel.Checked = True Then
                Dim fileChooser As SaveFileDialog = New SaveFileDialog
                If TemplateFile.Contains(".xlsx") Then
                    fileChooser.DefaultExt = "xlsx"
                Else
                    fileChooser.DefaultExt = "xls"
                End If
                fileChooser.FileName = TemplateFile
                Dim result As DialogResult
                result = fileChooser.ShowDialog()
                fileChooser.CheckFileExists = True
                If result = DialogResult.OK Then
                    Dim WriteLine, ConfigLine, BorderLine, SaveConfigLine As Integer
                    WriteLine = ReportInformation("WriteLine")
                    ConfigLine = ReportInformation("ConfigLine")
                    BorderLine = ReportInformation("BorderLine")
                    If bSaveData = True Then
                        If MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Bancothucsumuonluu"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes Then
                            bisOpen = False
                        Else
                            bSaveData = False
                        End If
                    End If
                    Dim table As DataTable = kn.ReadData(CreateQueryForReport(), "table")
                    If IsNothing(table) Then
                        Exit Sub
                    End If
                    If table.Rows.Count = 0 Then
                        MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Khongcodulieudexuat"), "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Exit Sub
                    End If
                    'Dim Content As String = "2"
                    'If ReportInformation("ReportCode") = "BangLuongGuiNganHangBonus" Then
                    '    Content = para_Year.Text
                    'End If

                    If TemplateFile.Contains(".xlsx") Then
                        If Not IsDBNull(ReportInformation("Excel_XoaDenDong")) Then
                            Excel_XoaDenDong = ReportInformation("Excel_XoaDenDong")
                        End If
                        If Not IsDBNull(ReportInformation("GroupBy")) Then
                            bExportExcel = tvcn.XuatExcelTheoTableEPPlus(Application.StartupPath() + "\Teamleate\" + TemplateFile, fileChooser.FileName(), table, bisOpen, WriteLine, ConfigLine, BorderLine, Split(ReportInformation("GroupBy"), ","), ReturnValuesParameter, 1, NotDeleteConfig)
                        Else
                            bExportExcel = tvcn.XuatExcelTheoTableEPPlus(Application.StartupPath() + "\Teamleate\" + TemplateFile, fileChooser.FileName(), table, bisOpen, WriteLine, ConfigLine, BorderLine, "", ReturnValuesParameter(), Excel_XoaDenDong, True, NotDeleteConfig)
                        End If
                    Else
                        If Not IsDBNull(ReportInformation("GroupBy")) Then
                            bExportExcel = tvcn.XuatExcelTheoTable(Application.StartupPath() + "\Teamleate\" + TemplateFile, {"Sheet1"}, fileChooser.FileName(), table, bisOpen, WriteLine, ConfigLine, BorderLine, Split(ReportInformation("GroupBy"), ","), ReturnValuesParameter, 1, NotDeleteConfig)
                        Else
                            bExportExcel = tvcn.XuatExcelTheoTable(Application.StartupPath() + "\Teamleate\" + TemplateFile, fileChooser.FileName(), table, bisOpen, WriteLine, ConfigLine, BorderLine, "", ReturnValuesParameter(), True, NotDeleteConfig)
                        End If
                    End If
                    If bExportExcel = True Then
                        If bSaveData = True Then
                            If Quyen.ToUpper = "VIEW" Then
                                Exit Sub
                            End If
                            'Dim tabSaveSalaryInfor As DataTable = kn.ReadData("select * from HR_Report where ReportCode='" + ReportInformation("ReportCode") + "'", "table")
                            'If tabSaveSalaryInfor.Rows.Count > 0 Then
                            Dim PrimaryConfigLine As Integer
                            Dim InsertDateName, UserNameName As String
                            SaveConfigLine = ReportInformation("SaveConfigLine")
                            PrimaryConfigLine = ReportInformation("PrimaryConfigLine")
                            If Not IsDBNull(ReportInformation("InsertDateName")) Then
                                InsertDateName = ReportInformation("InsertDateName")
                            Else
                                InsertDateName = "InsertDate"
                            End If
                            If Not IsDBNull(ReportInformation("UserNameName")) Then
                                UserNameName = ReportInformation("UserNameName")
                            Else
                                UserNameName = "UserName"
                            End If
                            If IsDBNull(ReportInformation("NameOfTable")) Then
                                MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Banchuanhaptenbangdulieu"), "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                Exit Sub
                            End If
                            If TemplateFile.Contains(".xlsx") Then
                                'tvcn.NhapExcelEPPlus(ReportInformation("NameOfTable"), fileChooser.FileName(), SaveConfigLine, PrimaryConfigLine, WriteLine, InsertDateName, UserNameName)
                                tvcn.NhapExcelInteropExcel(ReportInformation("NameOfTable"), fileChooser.FileName(), SaveConfigLine, PrimaryConfigLine, WriteLine, InsertDateName, UserNameName)
                                Dim fi As New FileInfo(fileChooser.FileName())
                                System.Diagnostics.Process.Start(fileChooser.FileName())
                            Else
                                tvcn.NhapExcel("Sheet1", ReportInformation("NameOfTable"), fileChooser.FileName(), SaveConfigLine, PrimaryConfigLine, WriteLine, InsertDateName, UserNameName)
                                Dim ps As New ProcessStartInfo
                                ps.UseShellExecute = True
                                ps.FileName = fileChooser.FileName()
                                Process.Start(ps)
                            End If
                            'End If
                        End If
                    End If
                End If
            End If
        ElseIf GetTemplateFile.Checked = True Then
            Dim TemplateFile As String = ReportInformation("TemplateFile")
            tvcn.LayTemplateEPPlus(Application.StartupPath() + "\Teamleate\" + TemplateFile)
        ElseIf InputTemplateFile.Checked = True Then
            Dim WriteLine, ConfigLine, BorderLine, PrimaryConfigLine As Integer
            Dim InsertDateName, UserNameName As String
            WriteLine = ReportInformation("WriteLine")
            ConfigLine = ReportInformation("SaveConfigLine")
            PrimaryConfigLine = ReportInformation("PrimaryConfigLine")
            If Not IsDBNull(ReportInformation("InsertDateName")) Then
                InsertDateName = ReportInformation("InsertDateName")
            Else
                InsertDateName = "InsertDate"
            End If
            If Not IsDBNull(ReportInformation("UserNameName")) Then
                UserNameName = ReportInformation("UserNameName")
            Else
                UserNameName = "UserName"
            End If
            If IsDBNull(ReportInformation("NameOfTable")) Then
                MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Banchuanhaptenbangdulieu"), "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If
            Dim ofd As New OpenFileDialog
            With ofd
                '.FileName = "C:" & "\" & "TempImport\Received Files" 'Points it to the received files folder
                .Title = "Locate File"
                .Filter = "Excel file (*.xls)|*.xls|(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            End With
            If ofd.ShowDialog() = DialogResult.Cancel Then
                Exit Sub
            End If
            If MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Bancothucsumuonnhap"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then
                Exit Sub
            End If
            If ofd.FileName.Contains(".xlsx") Then
                tvcn.NhapExcelEPPlus(ReportInformation("NameOfTable"), ofd.FileName, ConfigLine, PrimaryConfigLine, WriteLine, InsertDateName, UserNameName)
            ElseIf ofd.FileName.Contains(".xls") Then
                tvcn.NhapExcel("Sheet1", ReportInformation("NameOfTable"), ofd.FileName, ConfigLine, PrimaryConfigLine, WriteLine, InsertDateName, UserNameName)
            End If
        ElseIf ExecStore.Checked = True Then
            If Quyen.ToUpper = "VIEW" Then
                MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Banchuanhaptenbangdulieu"), "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim tabThongBao As DataTable
            tabThongBao = kn.ReadData(CreateQueryForReport(), "table")
            If IsNothing(tabThongBao) Then
                MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Coloitrongquatrinhthuchien"), "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                If tabThongBao.Rows.Count > 0 Then
                    MessageBox.Show(tvcn.GetLanguagesTranslated("Popup." + tabThongBao.Rows(0)("ThongBao")), "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show(tvcn.GetLanguagesTranslated("Popup.Coloitrongquatrinhthuchien"), "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        End If
        bThucHienLenh = True
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
    Private Sub para_Factory_ID_ValueChanged(sender As Object, e As EventArgs) Handles para_Factory_ID.ValueChanged
        para_departmentcode.Value = DBNull.Value
        para_sectioncode.Value = DBNull.Value
        para_teamcode.Value = DBNull.Value
        para_departmentcode.DataSource = kn.ReadData("select * from [dbo].[udf_Department]('" + IIf(IsDBNull(para_Factory_ID.Value) = True, "", para_Factory_ID.Value) + "','" + obj.Lan + "',1)", "table")
        para_sectioncode.DataSource = kn.ReadData("select * from [dbo].[udf_Section]('" + IIf(IsDBNull(para_Factory_ID.Value) = True, "", para_Factory_ID.Value) + "',null,'" + obj.Lan + "',1)", "table")
        para_teamcode.DataSource = kn.ReadData("select * from [dbo].[udf_Team]('" + IIf(IsDBNull(para_Factory_ID.Value) = True, "", para_Factory_ID.Value) + "',null,null,'" + obj.Lan + "',1)", "table")
    End Sub
    Private Sub para_departmentcode_ValueChanged(sender As Object, e As EventArgs) Handles para_departmentcode.ValueChanged
        para_sectioncode.Value = DBNull.Value
        para_teamcode.Value = DBNull.Value
        Dim Filter As String
        Dim fact, dept As String
        fact = "null"
        dept = "null"
        If Not IsDBNull(para_departmentcode.Value) Then
            Filter = para_departmentcode.Value
            fact = "N'" + Split(Filter, "_")(0) + "'"
            dept = "N'" + Split(Filter, "_")(1) + "'"
        End If
        para_sectioncode.DataSource = kn.ReadData("select * from [dbo].[udf_Section](" + fact + "," + dept + ",'" + obj.Lan + "',1)", "table")
        para_teamcode.DataSource = kn.ReadData("select * from [dbo].[udf_Team](" + fact + "," + dept + ",null,'" + obj.Lan + "',1)", "table")
    End Sub
    Private Sub para_sectioncode_ValueChanged(sender As Object, e As EventArgs) Handles para_sectioncode.ValueChanged
        para_teamcode.Value = DBNull.Value
        Dim Filter As String
        Dim fact, dept, sect As String
        fact = "null"
        dept = "null"
        sect = "null"
        If Not IsDBNull(para_sectioncode.Value) Then
            Filter = para_sectioncode.Value
            fact = "N'" + Split(Filter, "_")(0) + "'"
            dept = "N'" + Split(Filter, "_")(1) + "'"
            sect = "N'" + Split(Filter, "_")(2) + "'"
        End If
        para_teamcode.DataSource = kn.ReadData("select * from [dbo].[udf_Team](" + fact + "," + dept + "," + sect + ",'" + obj.Lan + "',1)", "table")
    End Sub

    Private Sub para_Position_ValueChanged(sender As Object, e As EventArgs) Handles para_Position.ValueChanged
        para_Factory_ID.Value = DBNull.Value
        If Not IsDBNull(para_Position.Value) Then
            Dim ps As String() = Split(para_Position.Value, "_")
            para_Factory_ID.Value = ps(0)
            If ps.Length >= 2 Then
                para_departmentcode.Value = ps(0) + "_" + ps(1)
                If ps.Length >= 3 Then
                    para_sectioncode.Value = ps(0) + "_" + ps(1) + "_" + ps(2)
                    If ps.Length >= 4 Then
                        para_teamcode.Value = ps(0) + "_" + ps(1) + "_" + ps(2) + "_" + ps(3)
                    End If
                End If
            End If
        End If
        If Not IsDBNull(tabQuyenTX.Rows(0)("QuyenTruyXuat")) Then
            'para_Position.Enabled = False
            If Not IsDBNull(para_Factory_ID.Value) Then
                If para_Factory_ID.Value <> String.Empty Then
                    para_Factory_ID.Enabled = False
                End If
            End If
            If Not IsDBNull(para_departmentcode.Value) Then
                If para_departmentcode.Value <> String.Empty Then
                    para_departmentcode.Enabled = False
                End If
            End If
            If Not IsDBNull(para_sectioncode.Value) Then
                If para_sectioncode.Value <> String.Empty Then
                    para_sectioncode.Enabled = False
                End If
            End If
            If Not IsDBNull(para_teamcode.Value) Then
                If para_teamcode.Value <> String.Empty Then
                    para_teamcode.Enabled = False
                End If
            End If
        End If
    End Sub

    Public Function ObjectParameter() As Object()
        Dim arrlObject As New ArrayList()
        Dim strParameter, strQuery As String
        Dim ct As Control
        If Not IsDBNull(ReportInformation("Parameter")) Then
            For Each s As String In Split(ReportInformation("Parameter"), ",")
                If s.StartsWith("para_") Then
                    tvcn.FindControl(s, Me, ct)

                    If TypeOf ct Is Janus.Windows.CalendarCombo.CalendarCombo Then
                        arrlObject.Add(CType(ct, Janus.Windows.CalendarCombo.CalendarCombo).Value)
                    ElseIf TypeOf ct Is Janus.Windows.GridEX.EditControls.MultiColumnCombo Then
                        If IsNothing(CType(ct, Janus.Windows.GridEX.EditControls.MultiColumnCombo).Value) Then
                            arrlObject.Add("")
                        Else
                            If IsDBNull(CType(ct, Janus.Windows.GridEX.EditControls.MultiColumnCombo).Value) Then
                                arrlObject.Add("")
                            Else
                                arrlObject.Add(CType(ct, Janus.Windows.GridEX.EditControls.MultiColumnCombo).Value)
                            End If

                        End If
                    ElseIf TypeOf ct Is System.Windows.Forms.CheckBox Then
                        If CType(ct, System.Windows.Forms.CheckBox).Checked = True Then
                            arrlObject.Add(1)
                        Else
                            arrlObject.Add(0)
                        End If
                    ElseIf TypeOf ct Is System.Windows.Forms.RadioButton Then
                        If CType(ct, System.Windows.Forms.RadioButton).Checked = True Then
                            arrlObject.Add(1)
                        Else
                            arrlObject.Add(0)
                        End If
                    ElseIf TypeOf ct Is WindowsControlLibrary.Month Or TypeOf ct Is WindowsControlLibrary.Year Then
                        arrlObject.Add(ct.Text)
                    ElseIf ct.Name.ToUpper = "PARA_DANHSACHKEY" Then
                        arrlObject.Add(ct.Text)
                    Else
                        arrlObject.Add(ct.Text)
                    End If
                ElseIf s.StartsWith("#") And s.EndsWith("#") Then
                    If s.ToUpper = "#LAN#" Then
                        arrlObject.Add(obj.Lan)
                    ElseIf s.ToUpper = "#USERNAME#" Then
                        arrlObject.Add(obj.UserName)
                    End If
                ElseIf s.ToUpper = "NULL" Then
                    arrlObject.Add("")
                Else
                    arrlObject.Add(s)
                End If
            Next
        End If
        Return arrlObject.ToArray()
    End Function

    Public Function CreateQueryForReport() As String
        Dim strParameter, strQuery As String
        Dim ct As Control
        If Not IsDBNull(ReportInformation("Parameter")) Then
            For Each s As String In Split(ReportInformation("Parameter"), ",")
                If s.StartsWith("para_") Then
                    tvcn.FindControl(s, Me, ct)
                    strParameter += GetParameterInQuery(ct) + ","
                ElseIf s.StartsWith("#") And s.EndsWith("#") Then
                    If s.ToUpper = "#LAN#" Then
                        strParameter += "N'" + obj.Lan + "',"
                    ElseIf s.ToUpper = "#USERNAME#" Then
                        strParameter += "N'" + obj.UserName + "',"
                    End If
                Else
                    strParameter += s + ","
                End If
            Next
        End If
        If strParameter <> String.Empty Then
            strParameter = strParameter.Remove(strParameter.Length - 1, 1)
        End If
        'TAO QUERY TRUY VAN
        If Not IsDBNull(ReportInformation("NameOfFuntion")) Then
            strQuery = "select * from " + ReportInformation("NameOfFuntion") + " (" + strParameter + ")"
        ElseIf Not IsDBNull(ReportInformation("NameOfStore")) Then
            strQuery = "exec " + ReportInformation("NameOfStore") + " " + strParameter
        ElseIf Not IsDBNull(ReportInformation("NameOfTable")) Then
            strQuery = "select * from [dbo].[" + ReportInformation("NameOfTable") + "]"
        End If
        tvcn.GhiNoiDungVaoFileDebug(tvcn.GetAppPath() & "\LOG\Debug.txt", strQuery)
        Return strQuery
    End Function

    Public Function ReturnValuesParameter() As ArrayList
        Dim arrlRTN As New ArrayList
        Dim ct As Control
        If Not IsDBNull(ReportInformation("Parameter")) Then
            For Each s As String In Split(ReportInformation("Parameter"), ",")
                If s.StartsWith("para_") Then
                    tvcn.FindControl(s, Me, ct)
                    arrlRTN.Add(GetValueOfParameter(ct))
                ElseIf s.StartsWith("#") And s.EndsWith("#") Then
                    If s.ToUpper = "#LAN#" Then
                        arrlRTN.Add(obj.Lan)
                    ElseIf s.ToUpper = "#USERNAME#" Then
                        arrlRTN.Add(obj.UserName)
                    End If
                Else
                    arrlRTN.Add(s)
                End If
            Next
        End If
        Return arrlRTN
    End Function

    Private Sub btnXoa_Click(sender As Object, e As EventArgs) Handles btnXoa.Click
        para_Factory_ID.Text = String.Empty
    End Sub

    Private Function GetParameterInQuery(ByVal ct As Control)
        If TypeOf ct Is Janus.Windows.CalendarCombo.CalendarCombo Then
            Return "'" + CType(ct, Janus.Windows.CalendarCombo.CalendarCombo).Value.ToString("yyyy-MM-dd HH:mm:ss") + "'"
        ElseIf TypeOf ct Is Janus.Windows.GridEX.EditControls.MultiColumnCombo Then
            Return "N'" + CType(ct, Janus.Windows.GridEX.EditControls.MultiColumnCombo).Value + "'"
        ElseIf TypeOf ct Is System.Windows.Forms.CheckBox Then
            If CType(ct, System.Windows.Forms.CheckBox).Checked = True Then
                Return "1"
            Else
                Return "0"
            End If
        ElseIf TypeOf ct Is System.Windows.Forms.RadioButton Then
            If CType(ct, System.Windows.Forms.RadioButton).Checked = True Then
                Return "1"
            Else
                Return "0"
            End If
        ElseIf TypeOf ct Is WindowsControlLibrary.Month Or TypeOf ct Is WindowsControlLibrary.Year Then
            Return ct.Text
        ElseIf ct.Name.ToUpper = "PARA_DANHSACHKEY" Then
            Return "'" + ct.Text + "'"
        ElseIf ct.Name.ToUpper = "PARA_LEAVETYPE" Then
            Dim lt As String
            For Each gr As GridEXRow In para_LeaveType.GetCheckedRows
                lt = lt + gr.Cells("code").Value + ","
            Next
            If lt <> String.Empty Then
                lt = "'" + lt.Remove(lt.Length - 1, 1) + "'"
            Else
                lt = "null"
            End If
            Return lt
        Else
            Return "N'" + ct.Text.Trim + "'"
        End If
    End Function
    Private Function GetValueOfParameter(ByVal ct As Control)
        If TypeOf ct Is Janus.Windows.CalendarCombo.CalendarCombo Then
            Return CType(ct, Janus.Windows.CalendarCombo.CalendarCombo).Value
        ElseIf TypeOf ct Is Janus.Windows.GridEX.EditControls.MultiColumnCombo Then
            Return CType(ct, Janus.Windows.GridEX.EditControls.MultiColumnCombo).Value
        ElseIf TypeOf ct Is System.Windows.Forms.CheckBox Then
            If CType(ct, System.Windows.Forms.CheckBox).Checked = True Then
                Return "1"
            Else
                Return "0"
            End If
        ElseIf TypeOf ct Is System.Windows.Forms.RadioButton Then
            If CType(ct, System.Windows.Forms.RadioButton).Checked = True Then
                Return "1"
            Else
                Return "0"
            End If
        ElseIf TypeOf ct Is WindowsControlLibrary.Month Or TypeOf ct Is WindowsControlLibrary.Year Then
            Return ct.Text
        ElseIf ct.Name.ToUpper = "PARA_DANHSACHKEY" Then
            Return ct.Text
        Else
            Return ct.Text.Trim
        End If
    End Function
End Class
